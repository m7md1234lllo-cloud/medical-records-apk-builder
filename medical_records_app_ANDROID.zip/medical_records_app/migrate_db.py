#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Database Migration Script
سكريبت لترحيل وتحديث قاعدة البيانات
"""

import sqlite3
import os

DATABASE = 'medical_records.db'

def migrate_database():
    """تحديث قاعدة البيانات للنسخة الجديدة"""
    print("🔄 بدء تحديث قاعدة البيانات...")
    
    # حذف قاعدة البيانات القديمة إذا كانت موجودة
    if os.path.exists(DATABASE):
        backup_name = f'medical_records_backup_{os.path.getmtime(DATABASE)}.db'
        print(f"📦 إنشاء نسخة احتياطية: {backup_name}")
        
        try:
            # نسخ قاعدة البيانات القديمة
            import shutil
            shutil.copy2(DATABASE, backup_name)
            print("✅ تم إنشاء النسخة الاحتياطية بنجاح!")
        except Exception as e:
            print(f"⚠️  تحذير: لم يتم إنشاء نسخة احتياطية: {e}")
        
        # حذف قاعدة البيانات القديمة
        try:
            os.remove(DATABASE)
            print("🗑️  تم حذف قاعدة البيانات القديمة")
        except Exception as e:
            print(f"❌ خطأ في حذف قاعدة البيانات القديمة: {e}")
            return False
    
    print("✨ سيتم إنشاء قاعدة بيانات جديدة عند تشغيل التطبيق")
    print("✅ اكتمل التحديث!")
    return True

if __name__ == '__main__':
    print("=" * 50)
    print("🔧 أداة تحديث قاعدة البيانات")
    print("=" * 50)
    print()
    
    if migrate_database():
        print()
        print("✅ النظام جاهز للعمل!")
        print("شغل التطبيق الآن باستخدام: python app.py")
    else:
        print()
        print("❌ فشل التحديث!")
        print("يرجى التواصل مع الدعم الفني")
